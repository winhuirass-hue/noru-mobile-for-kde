// ── Surfaces ──────────────────────────────────────────────
var background    = "#101015";
var surface       = "#16161e";
var surfaceHigh   = "#1e1e2a";
var surfaceFloat  = "#22223080";   // translucent panels
var border        = "#2a2a3a";

// ── Accent Palette ────────────────────────────────────────
// Available: "green" | "blue" | "purple" | "red" | "orange" | "cyan" | "pink" | "gold"
var accentName = "green";

var _accents = {
    "green":  { base: "#3ddc84", dim: "#3ddc8440", hover: "#5eeaa0", glow: "#3ddc8418" },
    "blue":   { base: "#4488ff", dim: "#4488ff40", hover: "#66aaff", glow: "#4488ff18" },
    "purple": { base: "#a855f7", dim: "#a855f740", hover: "#c084fc", glow: "#a855f718" },
    "red":    { base: "#ff4d4d", dim: "#ff4d4d40", hover: "#ff7070", glow: "#ff4d4d18" },
    "orange": { base: "#ff8c42", dim: "#ff8c4240", hover: "#ffaa6e", glow: "#ff8c4218" },
    "cyan":   { base: "#22d3ee", dim: "#22d3ee40", hover: "#67e8f9", glow: "#22d3ee18" },
    "pink":   { base: "#ec4899", dim: "#ec489940", hover: "#f472b6", glow: "#ec489918" },
    "gold":   { base: "#f0b429", dim: "#f0b42940", hover: "#f7cc5e", glow: "#f0b42918" }
};

var accent      = _accents[accentName].base;
var accentDim   = _accents[accentName].dim;
var accentHover = _accents[accentName].hover;
var accentGlow  = _accents[accentName].glow;

// ── Status Colors ─────────────────────────────────────────
var success     = "#3ddc84";
var warning     = "#ffaa33";
var danger      = "#ff5555";

// ── Runtime accent switcher ───────────────────────────────
function setAccent(name) {
    if (!_accents[name]) return false;
    accentName  = name;
    accent      = _accents[name].base;
    accentDim   = _accents[name].dim;
    accentHover = _accents[name].hover;
    accentGlow  = _accents[name].glow;
    return true;
}

function accentList() {
    return Object.keys(_accents);
}

// ── Text ──────────────────────────────────────────────────
var textPrimary   = "#e8e8f0";
var textSecondary = "#8888aa";
var textDisabled  = "#444460";

// ── Geometry ──────────────────────────────────────────────
var radius        = 12;
var radiusSmall   = 6;
var taskbarHeight = 56;
var activityWidth = 64;
var panelBlur     = 18;

// ── Motion ────────────────────────────────────────────────
var durationFast  = 120;
var durationNorm  = 220;
var durationSlow  = 380;
var easing        = "Easing.OutCubic";