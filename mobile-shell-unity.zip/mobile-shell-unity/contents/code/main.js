
// ScriptGlue: hook DBus/KRunner to actually launch apps
var ScriptGlue = {
    launch: function(cmd) {
        print("[MobileShell] launch request: " + cmd);
        // TODO: Wire to klauncher or KRunner via DBus from a small helper
    }
};
