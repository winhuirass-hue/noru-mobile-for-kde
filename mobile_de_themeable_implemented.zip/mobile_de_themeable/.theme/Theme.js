// ── Surfaces ──────────────────────────────────────────────
var background    = "#101015";
var surface       = "#16161e";
var surfaceHigh   = "#1e1e2a";
var surfaceFloat  = "#22223080";   // translucent panels
var border        = "#2a2a3a";

// ── Accent & Status ───────────────────────────────────────
var accent        = "#4488ff";
var accentDim     = "#4488ff40";
var accentHover   = "#66aaff";
var success       = "#44cc88";
var warning       = "#ffaa33";
var danger        = "#ff5555";

// ── Text ──────────────────────────────────────────────────
var textPrimary   = "#e8e8f0";
var textSecondary = "#8888aa";
var textDisabled  = "#444460";

// ── Geometry ──────────────────────────────────────────────
var radius        = 12;
var radiusSmall   = 6;
var taskbarHeight = 56;
var activityWidth = 64;
var panelBlur     = 18;

// ── Motion ────────────────────────────────────────────────
var durationFast  = 120;
var durationNorm  = 220;
var durationSlow  = 380;
var easing        = "Easing.OutCubic";