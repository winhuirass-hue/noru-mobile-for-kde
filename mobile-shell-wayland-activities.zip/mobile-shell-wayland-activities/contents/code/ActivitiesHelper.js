
// Minimal helper to describe activity IDs using ActivityManager DBus when available
var ActivitiesHelper = {
    describe: function(id) {
        try {
            if (typeof callDBus === 'function' && id) {
                var d = callDBus('org.kde.ActivityManager', '/ActivityManager/Activities', 'org.kde.ActivityManager.Activities', 'ActivityDescription', [String(id)]);
                if (d && String(d).length > 0) return d;
            }
        } catch (e) {
            // ignore
        }
        // Fallback to short id
        return id ? String(id).slice(0, 8) : 'activity';
    }
};
