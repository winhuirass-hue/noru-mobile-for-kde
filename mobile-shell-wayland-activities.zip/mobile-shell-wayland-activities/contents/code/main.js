
var ScriptGlue = {
    launch: function(cmd) {
        try {
            if (typeof callDBus === "function") {
                var ok = callDBus("org.kde.klauncher6", "/KLauncher", "org.kde.KLauncher", "exec_blind", [String(cmd)]);
                if (ok !== undefined) { print("[MobileShell] launched via klauncher6: "+cmd); return true; }
            }
        } catch (e) { print("[MobileShell] klauncher6 failed: "+e); }
        try {
            if (typeof callDBus === "function") {
                var ok5 = callDBus("org.kde.klauncher5", "/KLauncher", "org.kde.KLauncher", "exec_blind", [String(cmd)]);
                if (ok5 !== undefined) { print("[MobileShell] launched via klauncher5: "+cmd); return true; }
            }
        } catch (e2) { print("[MobileShell] klauncher5 failed: "+e2); }
        try {
            if (typeof callDBus === "function") {
                callDBus("org.kde.krunner1", "/org/kde/krunner1", "org.kde.krunner1", "Query", [String(cmd)]);
                print("[MobileShell] query sent to krunner: "+cmd);
                return true;
            }
        } catch (e3) { print("[MobileShell] krunner query failed: "+e3); }
        print("[MobileShell] launch request (no suitable backend found): "+cmd);
        return false;
    }
};
